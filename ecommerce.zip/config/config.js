const config = {
    secret_jwt : "thismysecretkey",
    emailUser:'ec19.yogeshmangule@svceindore.ac.in',
    emailPassword:'Yogesh@2023'
}

module.exports = config;